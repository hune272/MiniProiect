import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Alien {
    private int x;
    private int y;
    private final int WIDTH = 50;
    private final int HEIGHT = 50;

    public Alien(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void draw(Graphics g) {
        g.setColor(Color.green);
        g.fillRect(x, y, WIDTH, HEIGHT);
    }

    public void move(){
        y += 1;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, WIDTH, HEIGHT);
    }

}
