import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GamePanel extends JPanel implements ActionListener {
    private SpaceShip spaceShip;
    private ArrayList<Alien> aliens;
    private ArrayList<Projectile> projectiles;
    private Timer timer, alienSpawner;
    private Random random = new Random();
    private int score = 0;

    public GamePanel() {
        spaceShip = new SpaceShip(375, 550);
        aliens = new ArrayList<>();
        projectiles = new ArrayList<>();
        timer = new Timer(10, this);
        timer.start();
        alienSpawner = new Timer(2000, e -> spawnAlien());
        alienSpawner.start();

        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                spaceShip.keyPressed(e);
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    projectiles.add(new Projectile(spaceShip.getX() + 15, spaceShip.getY()));
                }
            }
        });
    }

    private void spawnAlien() {
        int x = random.nextInt(800 - 30);
        aliens.add(new Alien(x, 0));
    }

    public void actionPerformed(ActionEvent e) {
        spaceShip.move();
        for (Projectile projectile : projectiles) {
            projectile.move();
        }
        for (Alien alien : aliens) {
            alien.move();
        }
        checkCollisions();
        repaint();
    }

    private void checkCollisions() {
        Iterator<Projectile> projIter = projectiles.iterator();
        while (projIter.hasNext()) {
            Projectile projectile = projIter.next();
            Iterator<Alien> alienIter = aliens.iterator();
            while (alienIter.hasNext()) {
                Alien alien = alienIter.next();
                if (projectile.getBounds().intersects(alien.getBounds())) {
                    projIter.remove();
                    alienIter.remove();
                    score += 1;
                    break;
                }
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        spaceShip.draw(g);
        for (Alien alien : aliens) {
            alien.draw(g);
        }
        for (Projectile projectile : projectiles) {
            projectile.draw(g);
        }
        displayScore(g);
    }

    private void displayScore(Graphics g) {
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 18));
        g.drawString("Score: " + score, 700, 30);
    }
}
