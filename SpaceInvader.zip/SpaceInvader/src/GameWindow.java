import javax.swing.JFrame;
import java.awt.*;

public class GameWindow extends JFrame {
    public GameWindow() {
        this.setTitle("Space Invaders");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBackground(Color.BLACK);
        this.setSize(800, 600);
        this.add(new GamePanel());
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        new GameWindow();
    }
}
