import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Projectile {
    private int x;
    private int y;

    public Projectile(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }

    public void move(){
        y -= 2;
    }

    public void draw(Graphics g){
        g.setColor(Color.blue);
        g.fillOval(x,y,8,15);//imaginea projectile
    }

    public Rectangle getBounds(){
        return new Rectangle(x,y,8,15);
    }

}
