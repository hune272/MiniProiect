import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.Rectangle;

public class SpaceShip {
    private int x;
    private int y;
    private int keyX;
    private final int WIDTH = 70;
    private final int HEIGHT = 50;

    public SpaceShip(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void move(){
        this.x += keyX;
        if(x < 0){x = 0;}
        if(x > 770){x = 770;}
    }

    public void draw(Graphics g){
        g.setColor(Color.WHITE);
        g.fillRect(x, y, WIDTH, HEIGHT);
    }

    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_LEFT){
            keyX = -3;
        }
        if(e.getKeyCode() == KeyEvent.VK_RIGHT){
            keyX = +3;
        }
    }

    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }

    public Rectangle getBounds(){
        return new Rectangle(x, y, WIDTH, HEIGHT);
    }
}
